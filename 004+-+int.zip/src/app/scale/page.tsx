export default function ScalePage() {
  return <div>Scale Page!</div>;
}
