export default function ReliabilityPage() {
  return <div>Reliability Page!</div>;
}
